from fastapi import APIRouter, status

from app.schemas.survey import SurveyCreate
from app.services.survey_service import create_survey


router = APIRouter(
    prefix="/api/surveys",
    tags=["Surveys"]
)


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_survey_endpoint(survey: SurveyCreate):
    return await create_survey(survey)


@router.get("/")
async def get_surveys():
    return await get_surveys()