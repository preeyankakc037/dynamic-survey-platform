from datetime import datetime, timezone

from bson import ObjectId
from pymongo import ReturnDocument

from app.config.database import surveys_collection